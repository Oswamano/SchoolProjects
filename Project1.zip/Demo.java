import org.antlr.runtime.*;
import java.util.*;
import java.io.*;
class Demo{

  public static void main(String[] args) throws Exception{
        FileOutputStream output = new FileOutputStream("sample.tck");
	String workingdir=System.getProperty("user.dir");
	CharStream input = new ANTLRStringStream(workingdir +" /" +args[0]);
	Lool lexer = new Lool(input);
	while(true){	
	Token token = lexer.nextToken();
                if(token.getType() == token.EOF )
			break;
		else if(token.getType()==lexer.MODULE)
			System.out.print("MODULE ");
		else if(token.getType() == lexer.IF)
			System.out.print(token.getText()+ " ");
        else if(token.getType()==lexer.ID)
			System.out.print("ID ");
		 else if(token.getType()==lexer.CHILDOF)
			System.out.print("childof ");
		 else if(token.getType()==lexer.VIRTUAL)
			System.out.print("VIRTUAL ");
		 else if(token.getType()==lexer.CREATE)
			System.out.print("create ");
		 else if(token.getType()==lexer.INT)
			System.out.print("INT ");
		 else if(token.getType()==lexer.BOOL)
			System.out.print("Bool ");
		 else if(token.getType()==lexer.STRING)
			System.out.print("String ");
		 else if(token.getType()==lexer.VOID)
			System.out.print("VOID ");
			 else if(token.getType()==lexer.AND)
			System.out.print("and ");
			 else if(token.getType()==lexer.OR)
			System.out.print("or ");
			 else if(token.getType()==lexer.NOT)
			System.out.print("not ");
			 else if(token.getType()==lexer.TRUE)
			System.out.print("true ");
			 else if(token.getType()==lexer.FALSE)
			System.out.print("false ");
			 else if(token.getType()==lexer.RETURN)
			System.out.print("return ");
		
			 else if(token.getType()==lexer.THEN)
			System.out.print("then ");
			 else if(token.getType()==lexer.ELSE)
			System.out.print("else ");
			 else if(token.getType()==lexer.ENDIF)
			System.out.print("endif ");
			 else if(token.getType()==lexer.WHILE)
			System.out.print("while ");
			 else if(token.getType()==lexer.LOOP)
			System.out.print("loop ");
			 else if(token.getType()==lexer.ENDLOOP)
			System.out.print("endloop ");
			 else if(token.getType()==lexer.BREAK)
			System.out.print("break ");
			 else if(token.getType()==lexer.CONTINUE)
			System.out.print("continue ");
			 else if(token.getType()==lexer.READ)
			System.out.print("read ");
			 else if(token.getType()==lexer.WRITE)
			System.out.print("write ");
			 else if(token.getType()==lexer.ERROR1)
			System.out.print("Err1 ");
			else if(token.getType()==lexer.ERR2)
			System.out.print("Err2 ");
			else if(token.getType()==lexer.ERROR3)
			System.out.print("Err3 ");
			else if(token.getType()==lexer.ZERO)
			System.out.print("IntLit ");
			else if(token.getType()==lexer.ASSING)
			System.out.print(":= ");
			else if(token.getType()==lexer.EQ)
			System.out.print("= ");
			else if(token.getType()==lexer.GR)
			System.out.print("> ");
			else if(token.getType()==lexer.SM)
			System.out.print("< ");
			else if(token.getType()==lexer.GE)
			System.out.print(">= ");
			else if(token.getType()==lexer.SE)
			System.out.print("<= ");
			else if(token.getType()==lexer.NE)
			System.out.print("!= ");
			else if(token.getType()==lexer.SemiColon)
			System.out.print("; ");
			else if(token.getType()==lexer.Dot)
			System.out.print(". ");
			else if(token.getType()==lexer.Colon)
			System.out.print(": ");
			else if(token.getType()==lexer.Comma)
			System.out.print(", ");
			else if(token.getType()==lexer.BraceStart)
			System.out.print("{ ");
			else if(token.getType()==lexer.BraceEnd)
			System.out.print("} ");
			else if(token.getType()==lexer.BracketsStart)
			System.out.print("[ ");
			else if(token.getType()==lexer.BracketsEnd)
			System.out.print("] ");
			else if(token.getType()==lexer.ParenthesesStart)
			System.out.print("( ");
			else if(token.getType()==lexer.ParenthesesEnd)
			System.out.print(") ");
			else if(token.getType()==lexer.Sum)
			System.out.print("+ ");
			else if(token.getType()==lexer.Minus)
			System.out.print("- ");
			else if(token.getType()==lexer.NUMBER)
			System.out.print(token.getText() );
			else if(token.getType()==lexer.COMMENT)
			System.out.print("SingleLineComment ");
			else if(token.getType()==lexer.MULTICOMMENT)
			System.out.print("MultiComment ");
			
		
	}
	output.close();
	System.out.print("Done");
  }
}
