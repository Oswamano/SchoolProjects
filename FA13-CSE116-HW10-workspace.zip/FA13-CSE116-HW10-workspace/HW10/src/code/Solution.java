package code;

public class Solution {

	public String question1() {
		return "";
	}

	public String question2() {
		return "";
	}

}
